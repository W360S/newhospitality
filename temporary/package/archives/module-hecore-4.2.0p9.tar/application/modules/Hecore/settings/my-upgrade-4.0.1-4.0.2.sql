--
-- Update module Hecore
--

UPDATE `engine4_core_modules` SET `version` = '4.0.2'  WHERE `name` = 'hecore';