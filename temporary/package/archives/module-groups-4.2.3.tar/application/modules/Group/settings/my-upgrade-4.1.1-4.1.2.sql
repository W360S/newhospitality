
UPDATE `engine4_core_pages`
SET `provides` = 'subject=group'
WHERE `name` = 'group_profile_index' ;
