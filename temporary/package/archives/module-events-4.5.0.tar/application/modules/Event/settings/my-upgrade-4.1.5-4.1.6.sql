
ALTER TABLE `engine4_event_events`
  CHANGE COLUMN `description` `description` text NOT NULL ;
