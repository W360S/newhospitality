
UPDATE `engine4_core_pages`
SET `provides` = 'subject=event'
WHERE `name` = 'event_profile_index' ;
