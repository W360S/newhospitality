
ALTER TABLE `engine4_group_groups`
  CHANGE COLUMN `description` `description` text NOT NULL ;
