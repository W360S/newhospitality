
INSERT IGNORE INTO `engine4_core_menuitems` (`name`, `module`, `label`, `plugin`, `params`, `menu`, `submenu`, `order`) VALUES
('authorization_admin_level_forum', 'forum', 'Forums', '', '{"route":"admin_default","module":"forum","controller":"level","action":"index"}', 'authorization_admin_level', '', 999)
;
