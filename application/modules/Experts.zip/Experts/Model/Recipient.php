<?php

class Experts_Model_Recipient extends Core_Model_Item_Abstract
{
  
}