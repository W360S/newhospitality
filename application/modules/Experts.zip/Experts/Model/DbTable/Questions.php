<?php

class Experts_Model_DbTable_Questions extends Engine_Db_Table
{
  protected $_rowClass = 'Experts_Model_Question';
  //protected $_expertsCategories;
}