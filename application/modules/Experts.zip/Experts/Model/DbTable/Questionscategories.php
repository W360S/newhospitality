<?php

class Experts_Model_DbTable_Questionscategories extends Engine_Db_Table
{
  //protected $_rowClass = 'Experts_Model_Questionscategory';
  //protected $_expertsCategories;
}