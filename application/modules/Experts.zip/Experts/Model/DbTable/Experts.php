<?php

class Experts_Model_DbTable_Experts extends Engine_Db_Table
{
  protected $_rowClass = 'Experts_Model_Expert';
}