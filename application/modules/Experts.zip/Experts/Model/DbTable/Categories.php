<?php

class Experts_Model_DbTable_Categories extends Engine_Db_Table
{
  protected $_rowClass = 'Experts_Model_Category';
}